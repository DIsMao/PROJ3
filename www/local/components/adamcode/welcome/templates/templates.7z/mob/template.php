
  <div class="mob__account" style="user-select: auto;">
                    <a class="widget__lk__info" href="<?=$arParams["LK_LINK"]?>">
                            <div class="widget__lk__img">
                                <img src="<?=$arResult["USER_INFO"]["PHOTO"]?>?>">
                                    <div class="widget__lk__counter header">0</div>

                            </div>

                                <div class="widget__lk__block">
                                    <p   style="margin-bottom: 5px;">Здравствуйте,</p>

                                    <div class="widget__lk__fio "><?=$arResult["USER_INFO"]["NAME"]?></div>

</div>

</a>